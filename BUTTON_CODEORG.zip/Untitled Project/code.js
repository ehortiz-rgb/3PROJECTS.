onEvent("BUTTON", "click", function( ) {
  setProperty("screen1", "image", "images-(1).jpeg");
  onEvent("BUTTON", "click", function( ) {
    setProperty("screen1", "image", "assets/eff7891dfee4d2c4035a32bd345d205d.jpg");
  });
});
onEvent("label1", "click", function( ) {
  setProperty("label1", "text", "CAISTEEES");
});
onEvent("image1", "click", function( ) {
  playSound("Smash-Mouth--All-Star-with-Lyrics---SM-ASWL-(youtube).mp3", false);
});
