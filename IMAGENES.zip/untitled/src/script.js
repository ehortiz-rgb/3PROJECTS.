// Array de imágenes
const imagenes = [
  "https://plus.unsplash.com/premium_photo-1661902398022-762e88ff3f82?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dG9raW98ZW58MHx8MHx8fDA%3D",
  "https://plus.unsplash.com/premium_photo-1661964177687-57387c2cbd14?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHRva2lvfGVufDB8fDB8fHww",
  "https://images.unsplash.com/photo-1551322120-c697cf88fbdc?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fHRva2lvfGVufDB8fDB8fHww",
  "https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mzh8fHRva2lvfGVufDB8fDB8fHww",
  "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjh8fHRva2lvfGVufDB8fDB8fHww"
];

// Selección de elementos
const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

// Contador de imágenes
let indice = 0;

// Evento click
boton.addEventListener("click", () => {
  indice++;
  if (indice >= imagenes.length) {
    indice = 0; // Reinicia al inicio
  }

  // Cambiar imagen y texto
  imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});
